from __future__ import division

from collections import Counter
from corpus import Corpus
from trainingcorpus import TrainingCorpus
import utils
import confmat



class MyFilter:
    prob_Spam_Word = {}
    model = {}

    def __init__(self):
        self.prob_Spam_Word = {}
        self.spam_email = 'SPAM'
        self.ham_email = 'OK'
        self.model={}


    def train(self, directory): #computes probability that each word appears in spam or ham
        self.directory = directory
        train_corp = TrainingCorpus()
        corpus = Corpus(directory)
        emails = corpus.emails()

        email_dict = train_corp.get_email_body(emails)
        labels = utils.read_classification_from_file(directory + '/!truth.txt')
        ok_words_count = Counter()
        spam_words_count = Counter()
        number_of_spam = 0
        number_of_ham = 0
        for i in email_dict.keys():
            if labels[i] == 'OK':
                ok_words_count.update(email_dict[i])
                number_of_ham += 1
            else:
                number_of_spam += 1
                spam_words_count.update(email_dict[i])

        prob_spam_word = self.compute_prob_spam_word(ok_words_count, spam_words_count, number_of_spam,
                                                     number_of_ham)  # Pr(S|W)
        self.model = prob_spam_word  # return model


    def test(self, directory): #tests our model on the given test-data
        corpus = Corpus(directory)
        emails = corpus.emails()
        train_corpus = TrainingCorpus()
        email_dict = train_corpus.get_email_body(emails)
        with open(directory + '/!prediction.txt', 'w', encoding='utf-8') as f:
            for email in email_dict.keys():
                prob_spam = self.classify(email_dict[email])
                if prob_spam > 0.73:
                    f.write(email + ' ' + self.spam_email + '\n')
                else:
                    f.write(email + ' ' + self.ham_email + '\n')


    def classify(self, words):  # returns a probability of an email being spam
        prob_spam_word = 1
        prob_ham_word = 1
        for word in words:
            if not (word in self.model):
                continue
            if (self.model[word] < 0.6) and (self.model[word] > 0.4):
                continue
            prob_spam_word *= self.model[word]
            prob_ham_word *= (1 - self.model[word])
        return prob_spam_word / (prob_spam_word + prob_ham_word)


    # probability P(S|W) is computed using bayes formula.
    # rare words -- formula P(S|W)=(s*P(S)+n*P(S|W))/(s+n) where
    # s  is the strength we give to background information about incoming spam ;
    # n is  is the number of occurrences of this word during the learning phase
    def compute_prob_spam_word(self, ok_words_count, spam_words_count, number_of_spam, number_of_ham):  # Pr(S|W)
        strength = 1
        prob_spam = 0.5
        output = {}
        for word, count in spam_words_count.items():
            prob_word_spam = count / number_of_spam
            prob_word_ham = ok_words_count[word] / number_of_ham
            prob_spam_word = prob_spam * prob_word_spam / ((1 - prob_spam) * prob_word_ham + (prob_spam) * prob_word_spam)
            output[word] = ((strength * prob_spam) + count * prob_spam_word) / (strength + count)
        return output


