class TrainingCorpus:
    word_count = 0
    black_list = ['the', 'this', 'that', 'and', 'are', 'you', 'your', 'with', 'our']
    word_black_list = set()

    def __init__(self):
        self.word_count = 0
        self.word_black_list = set(self.black_list)

    def get_email_body(self, emails):
        output_dict = {}
        for FILEname, body in emails:

            try:
                body = body.split('Content-Type')[1]
            except IndexError:
                body = body
            words = body.split()
            filtered_words = self.filter_words(words)
            filtered_words = self.to_lower_case(filtered_words)
            self.word_count += len(filtered_words)
            output_dict[FILEname] = filtered_words
        return output_dict

    def filter_words(self, words):
        output = []
        for word in words:
            if len(word) < 3:
                continue
            if ('<' in word) or ('>' in word) or ('=' in word) or ('.' in word):
                continue
            if word in self.word_black_list:
                continue
            word = ''.join(e for e in word if e.isalnum())
            if len(word) == 0 or word.isdigit():
                continue
            output.append(word)
        return output

    def to_lower_case(self, words):
        return set(map(lambda x: x.lower(), words))
