import re #this module provides regular expression matching operations

def read_classification_from_file(PATH):
    dict = {} #new dictionary
    FILE = open(PATH, "r", encoding='utf-8') #open the file
    lines = FILE.readlines() # reads a single line from the file
    for line in lines:
        matcher = re.findall(r'^(.+) (.+)$', line, re.M) #Return all non-overlapping matches of pattern in string, as a list of strings
        dict[str(matcher[0][0])] = str(matcher[0][1])
    FILE.close()
    return dict
