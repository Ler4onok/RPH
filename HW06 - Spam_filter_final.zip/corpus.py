import os #provides a way of using operating system dependent functionality

class Corpus:
    def __init__(self, PATH): #initialization
        self.PATH = PATH

    def emails(self):
        for FILEName in os.listdir(self.PATH): #return a list of the entries in the directory given by path
            if (FILEName.startswith("!")): continue
            FILE = open(self.PATH + '/' + FILEName, "r", encoding='utf-8',errors='ignore')
            yield (FILEName, FILE.read())
            FILE.close()
