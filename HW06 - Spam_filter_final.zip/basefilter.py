import random
import os

class BaseFilter:
    def __init__(self):
        self.cl = ''

    def train(self, directory):
        pass

    def test(self, directory):
        with open(directory + '/!prediction.txt', "w", encoding='utf-8') as f:
            for emName in os.listdir(directory):
                if (emName.startswith('!')): continue
                f.write(emName + ' ' + self.cl + '\n')
