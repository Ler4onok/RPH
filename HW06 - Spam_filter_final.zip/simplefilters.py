import random
import os
import basefilter
from queue import PriorityQueue


class NaiveFilter(basefilter.BaseFilter):
    def __init__(self):
        basefilter.BaseFilter.__init__(self)

class ParanoidFilter(basefilter.BaseFilter):
    def __init__(self):
        basefilter.BaseFilter.__init__(self)
        self.classification = 'SPAM'

class RandomFilter(basefilter.BaseFilter):
    def __init__(self):
        basefilter.BaseFilter.__init__(self)

    def test(self, directory):
        with open(directory + '/!prediction.txt', "w", encoding='utf-8') as f:
            for emName in os.listdir(directory):
                if (emName.startswith('!')): continue
                rand = random.random()
                if (rand < 0.5):
                    f.write(emName + ' OK\n')
                else:
                    f.write(emName + ' SPAM\n')


